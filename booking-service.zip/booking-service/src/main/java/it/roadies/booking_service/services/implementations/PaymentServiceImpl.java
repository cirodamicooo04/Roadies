package it.roadies.booking_service.services.implementations;

import com.stripe.exception.StripeException;
import com.stripe.model.Event;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import it.roadies.booking_service.data.dao.BookingRepository;
import it.roadies.booking_service.data.dto.request.PaymentRequest;
import it.roadies.booking_service.data.dto.response.PaymentResponse;
import it.roadies.booking_service.data.entities.Booking;
import it.roadies.booking_service.data.entities.enumeration.BookingStatus;
import it.roadies.booking_service.exceptions.BookingNotFoundException;
import it.roadies.booking_service.exceptions.StatusException;
import it.roadies.booking_service.services.BookingService;
import it.roadies.booking_service.services.PaymentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
@Slf4j
@RequiredArgsConstructor
public class PaymentServiceImpl implements PaymentService {
    private final BookingService bookingService;
    private final BookingRepository bookingRepository;

    @Override
    public void processStripeEvent(Event event) {
        if ("payment_intent.succeeded".equals(event.getType())) {
            PaymentIntent paymentIntent = (PaymentIntent) event.getDataObjectDeserializer().getObject().orElse(null);

            if (paymentIntent != null && paymentIntent.getMetadata().containsKey("bookingId")) {
                String bookingIdStr = paymentIntent.getMetadata().get("bookingId");
                try {
                    UUID bookingId = UUID.fromString(bookingIdStr);
                    bookingService.confirmBooking(bookingId);
                    log.info("Pagamento Stripe riuscito. Prenotazione {} confermata.", bookingId);
                } catch (IllegalArgumentException e) {
                    log.error("Il bookingId ricevuto da Stripe non è un UUID valido: {}", bookingIdStr, e);
                }
            } else {
                log.warn("Ricevuto webhook di successo da Stripe, ma nessun bookingId nei metadati. Evento ID: {}", event.getId());
            }

        } else if ("payment_intent.payment_failed".equals(event.getType())) {
            log.warn("Pagamento Stripe fallito per l'evento: {}", event.getId());
        }
    }

    @Override
    public PaymentResponse createPaymentIntent(PaymentRequest request) throws StripeException {
        Booking booking = bookingRepository.findById(request.getBookingId()).orElseThrow(() -> new BookingNotFoundException(request.getBookingId()));

        if (!booking.getStatus().equals(BookingStatus.RESERVE_CONFIRMED)) {
            throw new StatusException("Puoi pagare solo una prenotazione con posti confermati");
        }

        if (booking.getExpiresAt() == null || booking.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new StatusException("La prenotazione è scaduta");
        }

        if (booking.getTotalPrice() == null || booking.getTotalPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw new StatusException("Prezzo della prenotazione non valido");
        }

        PaymentIntentCreateParams params =
                PaymentIntentCreateParams.builder()
                        .setAmount(booking.getTotalPrice().longValue())
                        .setCurrency("eur")
                        .putMetadata("bookingId", booking.getId().toString())
                        .setAutomaticPaymentMethods(
                                PaymentIntentCreateParams.AutomaticPaymentMethods
                                        .builder()
                                        .setEnabled(true)
                                        .build()
                        )
                        .build();

        PaymentIntent paymentIntent = PaymentIntent.create(params);
        return new PaymentResponse(paymentIntent.getId(), paymentIntent.getClientSecret(), paymentIntent.getStatus());
    }

}